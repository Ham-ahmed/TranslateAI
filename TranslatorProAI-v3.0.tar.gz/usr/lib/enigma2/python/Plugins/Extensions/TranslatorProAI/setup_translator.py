#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
import shutil
from setuptools import setup

# إنشاء المجلدات اللازمة
def create_directories():
    dirs = [
        '/usr/lib/enigma2/python/Plugins/Extensions/TranslatorPlugin',
        '/usr/lib/enigma2/python/Plugins/Extensions/TranslatorPlugin/locales',
        '/usr/lib/enigma2/python/Plugins/Extensions/TranslatorPlugin/images',
    ]
    for d in dirs:
        if not os.path.exists(d):
            os.makedirs(d)

# نسخ الملفات
def copy_files():
    files_to_copy = [
        ('plugin.py', '/usr/lib/enigma2/python/Plugins/Extensions/TranslatorPlugin/'),
        ('__init__.py', '/usr/lib/enigma2/python/Plugins/Extensions/TranslatorPlugin/'),
        ('images/translator.png', '/usr/lib/enigma2/python/Plugins/Extensions/TranslatorPlugin/images/'),
    ]
    
    for src, dst in files_to_copy:
        if os.path.exists(src):
            shutil.copy2(src, dst)
            print(f"Copied {src} to {dst}")

if __name__ == "__main__":
    print("Installing Professional Translator Plugin for Enigma2...")
    create_directories()
    copy_files()
    print("Installation completed!")
    print("Please restart Enigma2 to use the plugin.")