from setuptools import setup, find_packages

setup(
    name='TranslateAI',
    version='5.8',
    packages=find_packages(),
    install_requires=[],
)